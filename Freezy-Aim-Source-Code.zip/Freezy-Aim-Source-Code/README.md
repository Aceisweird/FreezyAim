<p align="center">
  <img src="docs/images/logo.svg" alt="Freezy Aim logo" width="96">
</p>

<h1 align="center">Freezy Aim</h1>

<p align="center">A free, open-source crosshair overlay for games on Windows, macOS and Linux.</p>

<p align="center">
  <a href="../../releases/latest"><strong>Download for Windows</strong></a>
  &nbsp;·&nbsp;
  <a href="../../releases/latest">All downloads</a>
</p>

![The Freezy Aim home page](docs/images/home.webp)

## Features

- **Stays out of your way.** The crosshair stays on top, never takes focus, and lets
  every click pass straight through to your game.
- **Crosshair Editor.** Start from one of 20 bases, then shape the arms, frame and dot,
  and set colors, outline, opacity, glow and rotation with a live preview.
- **Draw your own.** Draw a crosshair by hand, with smoothing, mirroring, lines, circles,
  boxes and pixel snapping. Unsaved drawings are kept for you. Drawings stay sharp at any size.
- **Merge crosshairs.** Stack crosshairs on top of each other. Each keeps its own colors,
  and you can move, fade or reorder them.
- **Crosshair Browser.** Search more than 130 built-in crosshairs sorted into sections.
- **Recents and favorites.** Your last 10 crosshairs and your favorites are one click
  away on the home page.
- **Share and back up.** Swap crosshairs with a share code, and keep a backup file of all
  of them.
- **Quick shortcuts.** Show or hide the crosshair, or jump to your next favorite, without
  leaving your game. Windows only for now.
- **Make it yours.** Choose the app's theme, colors, font and text size in Settings.
- **Light while you play.** Close the app window and only the small overlay keeps
  running, ready in your system tray.

![The Crosshair Editor](docs/images/editor.webp)

## Get started

### Windows

1. Download [`FreezyAim.exe`](../../releases/latest).
2. Double-click it. There's nothing to install.
3. Pick a crosshair, then start your game in **borderless** or **windowed** mode.

To update, just open the new version, and it replaces the old one.

Freezy Aim needs Windows 10 or 11 with Microsoft Edge, which comes with both.

### macOS and Linux

1. Install [Python 3](https://www.python.org/downloads/) and the crosshair helper's
   dependency:

   ```
   pip install -r requirements.txt
   ```

2. Download your version from the [latest release](../../releases/latest), or
   [build it yourself](#build-from-source).
3. Make it runnable, then start it:

   ```
   chmod +x freezy-aim-linux-x64
   ./freezy-aim-linux-x64
   ```

The app opens in Chrome, Edge, Brave or Chromium if you have one, or your default browser
if not. On Linux, the crosshair needs X11 or XWayland.

## Closing the app

The red X at the top right closes everything, including the crosshair. Closing just the
window leaves the crosshair running, and you can reopen the window or quit from the Freezy
Aim icon in your system tray or menu bar.

## Common questions

### Why does my system warn me about the download?

Windows and macOS warn about new apps that aren't signed with a paid certificate. On
Windows, select **More info**, then **Run anyway**. On macOS, right-click the app and
select **Open**. You can also build it yourself from this source.

### Why can't I see the crosshair in my game?

Exclusive fullscreen can hide overlays. Switch your game to borderless or windowed mode.

### Is it allowed in competitive games?

Freezy Aim only draws a window over your screen. It doesn't read or change your game.
Some competitive games and tournaments still don't allow crosshair overlays, so check the
rules for the games you play.

### What does it do with my data?

Nothing leaves your computer. There are no accounts and no tracking, and Freezy Aim itself
makes no internet connections. The app window talks to the crosshair through a private
server that only your computer can reach, protected by a secret that changes every time
the app starts.

### Where are my crosshairs saved?

To find them, go to Settings > App > Open folder.

| System | Folder |
| --- | --- |
| Windows | `%APPDATA%\Freezy Aim` |
| macOS | `~/Library/Application Support/Freezy Aim` |
| Linux | `~/.config/Freezy Aim` |

### How do I share a crosshair?

Point at it in My crosshairs or the Crosshair Browser and select the share button, or use
**Copy share code** in the Crosshair Editor. Then send the code to a friend.
They select **Import code** under My crosshairs and paste it in.

### Can I change the logo?

Yes. Put a file named `logo.png` in that same folder.

## Platform support

| System | Status |
| --- | --- |
| Windows 10 and 11 | Full app, tested |
| macOS | Full app without shortcuts or start with the system. New, and not tested on a Mac yet |
| Linux | Full app without shortcuts or start with the system. New, and not tested on a Linux desktop yet |

If you try it on macOS or Linux, please [report how it goes](../../issues/new/choose).

## Build from source

You need [Go](https://go.dev/dl/) 1.24 or newer.

```
cd src
go test ./...
go build -trimpath -tags nethttpomithttp2 -ldflags "-s -w" -o freezy-aim .
```

On Windows, add `-H=windowsgui` inside the quotes and use `-o FreezyAim.exe`.

See [CONTRIBUTING.md](CONTRIBUTING.md) to get involved, including how to add crosshairs.

## License

Freezy Aim is released under the [MIT License](LICENSE). See
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the font and other third-party work
it includes.
